import matplotlib
from mpl_toolkits import mplot3d
from matplotlib import pyplot as plt
from matplotlib import cm
from matplotlib import image as mpimg
from matplotlib.pyplot import figure
import cv2
import numpy as np

def cartoonifier(imagepath):
    original_img = cv2.imread(imagepath) 
    
    # Because cv2 reads image in BGR format so converting to RGB
    
    original_img = cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB)

    # step 1: Use bilateral filter for edge-aware smoothing.

    smoothing = original_img # We won't alter the original image at this point

    num_down =  2 # number of downsampling steps 
    num_bilateral =  7 # number of bilateral filtering steps

    # downsample image using Gaussian pyramid(see opencv 'pyrDown()' function)
    for _ in range(num_down):
        smoothing = cv2.pyrDown(smoothing)

    # repeatedly apply small bilateral filter instead of applying one large filter

    # cv2.bilateralFilter(src, d, sigmaColor, sigmaSpace)
    # src - input image
    # d - Filter size
    # sigmaColor - Filter sigma in the color space (Range Filter)
    # sigmaSpace - Filter sigma in the coordinate space (Domain Filter)

    for _ in range(num_bilateral):
        smoothing = cv2.bilateralFilter(smoothing, 9, 9, 7)

    # upsample image to original size (see opencv 'pyrUp()' function)
    for _ in range(num_down):
        smoothing = cv2.pyrUp(smoothing)


    # Step2
    
    '''
        In this step we will blur the original image. 
        This is considered as a pre-processing step before we move on towards 
        the edge detection step. We will apply a median filter on the image, 
        which replaces each pixel value with the median value of all the pixels in a small neighborhood.
    '''
    
    # Convert to grayscale and apply median blur

    grayscale = cv2.cvtColor(original_img, cv2.COLOR_RGB2GRAY)

    median_blur = cv2.medianBlur(grayscale, 7) # 7 is the Kernel size


    # Step3
    
    '''
        In this step we will create an edge mask from the output produced in 
        step2 using adaptive thresholding 
    '''

    # Detect and enhance edges(see opencv 'adaptiveThreshold()' function)

    edge_mask = cv2.adaptiveThreshold(median_blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                    cv2.THRESH_BINARY, 9, 2)


    # Final Step
    
    '''
        In this step we will combine the output produced in step1 and step3 using a 
        bitwise and operator to produce our final output. (Note: You need to convert output 
        from step3 to color first)
    '''
    
    # Final Step: Convert back to color, bit-AND with color image

    converted_to_color = cv2.cvtColor(edge_mask, cv2.COLOR_GRAY2RGB)

    '''
    smoothing and converted_to_color might have different shapes so we need to adjust the rows and columns
    accordingly for bit-AND to execute successfully.

    '''

    rows_smoothing = smoothing.shape[0] # number of rows of image from output of step 1
    cols_smoothing = smoothing.shape[1] # number of columns of image from output of step 1

    rows_conv2color = converted_to_color.shape[0] # number of rows of colored image from step 3
    cols_conv2color = converted_to_color.shape[1] # number of columns of colored image from step 3

    # If rows unequal but columns equal

    if rows_smoothing != rows_conv2color and cols_smoothing == cols_conv2color:
        if rows_smoothing > rows_conv2color:
            for _ in range(rows_smoothing - rows_conv2color):
                smoothing = np.delete(smoothing, smoothing.shape[0] - 1, 0)
        else:
            for _ in range(rows_conv2color - rows_smoothing):
                converted_to_color = np.delete(converted_to_color, converted_to_color.shape[0] - 1, 0)
            
    # If rows equal but columns unequal

    elif rows_smoothing == rows_conv2color and cols_smoothing != cols_conv2color:
        if cols_smoothing > cols_conv2color:
            for _ in range(cols_smoothing - cols_conv2color):
                smoothing = np.delete(smoothing, smoothing.shape[1] - 1, 1)
        else:
            for _ in range(cols_conv2color - cols_smoothing):
                converted_to_color = np.delete(converted_to_color, converted_to_color.shape[1] - 1, 1)
            
    # If both rows and columns are unequal

    elif rows_smoothing != rows_conv2color and cols_smoothing != cols_conv2color:
        # Handling rows
        if rows_smoothing > rows_conv2color:
            for _ in range(rows_smoothing - rows_conv2color):
                smoothing = np.delete(smoothing, smoothing.shape[0] - 1, 0)
        else:
            for _ in range(rows_conv2color - rows_smoothing):
                converted_to_color = np.delete(converted_to_color, converted_to_color.shape[0] - 1, 0)
                
        # Handling columns
        if cols_smoothing > cols_conv2color:
            for _ in range(cols_smoothing - cols_conv2color):
                smoothing = np.delete(smoothing, smoothing.shape[1] - 1, 1)
        else:
            for _ in range(cols_conv2color - cols_smoothing):
                converted_to_color = np.delete(converted_to_color, converted_to_color.shape[1] - 1, 1)

    # bit-AND operation

    final = smoothing & converted_to_color

    # Show output

    return final
